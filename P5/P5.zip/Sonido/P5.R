library(tuneR)
library(seewave)
library(audio)

nombre <-readWave('nombre.wav')
apellidos <-readMP3('apellidos.mp3')

plot( extractWave(nombre, from = 1, to = 393984) )
plot( extractWave(apellidos, from = 1, to = 393984) )

str(nombre)
nombre

str(apellidos)
apellidos

filtro1 <- pastew(apellidos, nombre, output="Wave")
plot( extractWave(filtro1, from = 1, to = 393984) )
listen(filtro1)

filtro2 <- bwfilter(filtro1, channel=1, n=1, from=10000,
                  to=22000, bandpass=TRUE, listen = FALSE, output = "Wave")

listen(filtro2)

writeWave(filtro2, file.path('nombre_completo.wav'))

perro <-readWave('perro.wav')

perroECO <- echo(perro,f=22050,amp=c(0.8,0.4,0.2),delay=c(1,2,3),
                output="Wave")

alreves <- revw(perroECO, output='Wave')
listen(alreves)
writeWave(alreves, file.path('alreves.wav'))

